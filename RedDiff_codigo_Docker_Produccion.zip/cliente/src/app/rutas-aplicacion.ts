import { Routes } from '@angular/router';
import { guardianAdministrador } from './nucleo/identidad/guardian-administrador';
import { guardianAutenticacion } from './nucleo/identidad/guardian-autenticacion';
import { guardianInvitado } from './nucleo/identidad/guardian-invitado';

export const rutasAplicacion: Routes = [
  {
    path: 'iniciar-sesion',
    canActivate: [guardianInvitado],
    loadComponent: () =>
      import('./modulos/autenticacion/pagina-inicio-sesion').then(
        (modulo) => modulo.PaginaInicioSesion,
      ),
    title: 'RedDiff | Iniciar sesión',
  },
  {
    path: '',
    canActivate: [guardianAutenticacion],
    loadComponent: () =>
      import('./compartido/disposicion/disposicion-autenticada').then(
        (modulo) => modulo.DisposicionAutenticada,
      ),
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./modulos/inicio/pagina-inicio').then((modulo) => modulo.PaginaInicio),
        title: 'RedDiff | Inicio',
      },
      {
        path: 'dispositivos',
        loadComponent: () =>
          import('./modulos/dispositivos/pagina-dispositivos').then(
            (modulo) => modulo.PaginaDispositivos,
          ),
        title: 'RedDiff | Dispositivos',
      },
      {
        path: 'capturas',
        loadComponent: () =>
          import('./modulos/capturas/pagina-capturas').then((modulo) => modulo.PaginaCapturas),
        title: 'RedDiff | Capturas y versiones',
      },
      {
        path: 'comparaciones',
        loadComponent: () =>
          import('./modulos/comparaciones/pagina-comparaciones').then(
            (modulo) => modulo.PaginaComparaciones,
          ),
        title: 'RedDiff | Comparación diferencial',
      },
      {
        path: 'cumplimiento',
        loadComponent: () =>
          import('./modulos/cumplimiento/pagina-cumplimiento').then(
            (modulo) => modulo.PaginaCumplimiento,
          ),
        title: 'RedDiff | Línea base y cumplimiento',
      },
      {
        path: 'usuarios',
        canActivate: [guardianAdministrador],
        loadComponent: () =>
          import('./modulos/usuarios/pagina-usuarios').then((modulo) => modulo.PaginaUsuarios),
        title: 'RedDiff | Usuarios',
      },
      {
        path: 'auditorias',
        canActivate: [guardianAdministrador],
        loadComponent: () =>
          import('./modulos/auditorias/pagina-auditorias').then(
            (modulo) => modulo.PaginaAuditorias,
          ),
        title: 'RedDiff | Bitácora de auditoría',
      },
    ],
  },
  {
    path: '**',
    redirectTo: '',
  },
];
