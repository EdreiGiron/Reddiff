# Documentación de despliegue

El despliegue admitido utiliza Docker Compose sobre un único servidor Linux. El procedimiento completo, los puertos, la preparación de certificados, los respaldos y la reversión se describen en [Producción con Docker Compose](produccion-docker-compose.md).

La composición conserva PostgreSQL y las claves criptográficas en volúmenes diferentes, no publica la base de datos y exige HTTPS para la web y validación TLS completa entre la API y PostgreSQL.
